#  ===============================================================
#  Working
#  =========
import pymysql

def get_connection():
    print("Starting connection...")
    try: 
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='kol@mind1',
            database='product_db',
            connect_timeout=5
        )
        if conn.open:
            print("Connection successful!")
            return conn
        else:
             print("Connection failed!")

    except pymysql.MySQLError as e:
        print(f"Error connecting to the database: {e}")

    except Exception as ex:
        print(f"Unexpected Error: {ex}")

    return None


#  ===============================================================
#  NOT WORKING
#  ===============
# import mysql.connector
 
# def get_connection():
#     try:
#         print("get connection called")
#         conn = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="kol@mind1",
#             database="product_db"
#         )
#         if conn.is_connected():
#             print("get connection leaving")
#             return conn
        
#     except mysql.connector.Error as e:
#         print(e)
#     except Exception as ex:
#         print(f"Unexpected Error: {ex}")   

#     return None


#  ===============================================================
#  NOT WORKING
#  ===============
# import mysql.connector
# def get_connection():
#     try:
#         mydb = mysql.connector.connect(
#             host="localhost",
#             port=3306,  # Change this if your MySQL runs on another port
#             user="root",
#             password="kol@mind1",
#             database="product_db"
#         )
#         if mydb.is_connected():
#             print("Connected to database")
#             return mydb
#         else:
#             print("NOT connected to database")

#     except mysql.connector.Error as err:
#         print(f"Error connecting to MySQL: {err}")

#     except Exception as ex:
#         print(f"Unexpected Error: {ex}")
    
#     return None
        



#  ===============================================================
# print("🚀 Script starting...")
# connection = get_connection()
# if connection:
#     print("🔚 Closing connection")
#     connection.close()
