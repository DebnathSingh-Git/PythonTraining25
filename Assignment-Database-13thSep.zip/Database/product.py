from db import get_connection
 
#create a product
def add_product(name, price, stock):
    try:
        conn = get_connection()
        # print(conn)

        cursor = conn.cursor()
        query = "Insert into products(name,price,stock) values(%s,%s,%s)"
        cursor.execute(query,(name,price,stock))
        conn.commit()
        print(f"Product '{name}' is added succesfully !!")
        cursor.close()
        conn.close()
    except Exception as e:
        print(e)
   
   
#fetch all the products
def list_product():
    conn = get_connection()
    cursor = conn.cursor()
    query = "select * from products"
    cursor.execute(query)
    rows = cursor.fetchall()
    print("Products below")
   
    for row in rows:
        print(f"ID: {row[0]}, Name: {row[1]}, Price: {row[2]}, Stock:{row[3]}")
       
    cursor.close()
    conn.close()
   
#update the product
def update_product(product_id, name=None, price=None, stock=None):
    conn = get_connection()
    cursor = conn.cursor()
   
    if name is not None:
        cursor.execute("update products set name=%s where id=%s",(name,product_id))
    if price is not None:
        cursor.execute("update products set price=%s where id=%s",(price,product_id))
    if stock is not None:
        cursor.execute("update products set stock=%s where id=%s",(stock,product_id))
       
    conn.commit()
    print(f"Product ID{product_id} updated successfully !!")
    cursor.close()
    conn.close()
   
   
#delete a product
def delete_product(product_id):
    conn = get_connection()
    cursor = conn.cursor()
    query = "delete from products where id=%s"
    cursor.execute(query,(product_id))
    conn.commit()
    print(f"Product '{product_id}' is deleted succesfully !!")
    cursor.close()
    conn.close()
 