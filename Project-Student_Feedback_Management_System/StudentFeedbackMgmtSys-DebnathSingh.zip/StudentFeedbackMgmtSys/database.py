# database.py

import pymysql
from custom_exceptions import DatabaseConnectionError
from logger import Logger
import config

class DatabaseConnection:
    def __init__(self):
        self.conn = None
        self.logger = Logger()


    def createDB(self):
        try:
            # Connect to MySQL server (not to a specific database)
            connection = pymysql.connect(host=config.MYSQL_HOST,
                                        user=config.MYSQL_USER,
                                        password=config.MYSQL_PASSWORD)
            cursor = connection.cursor()

            # Create the database
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {config.MYSQL_DATABASE}")
            self.logger.write_log(f"Database '{config.MYSQL_DATABASE}' created (or already exists).")

        except pymysql.MySQLError as e:
            print("Error creating database:", e)

        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()


    def connect(self):
        try:
            self.conn = pymysql.connect(
                host=config.MYSQL_HOST,
                user=config.MYSQL_USER,
                password=config.MYSQL_PASSWORD,
                database=config.MYSQL_DATABASE,
                connect_timeout=config.MYSQL_CONNECTION_TIMEOUT,
                cursorclass=pymysql.cursors.DictCursor
            )
            if self.conn.open:
                self.logger.write_log("Database connected successfully.")
            else:
                raise DatabaseConnectionError("Connection object is not connected.")
        except pymysql.MySQLError as err:
            self.logger.write_log(f"Database connection failed: {err}")
            raise DatabaseConnectionError(f"Unable to connect to database: {err}")

    def disconnect(self):
        if self.conn.cursor():
            self.conn.cursor().close()

        if self.conn and self.conn.open:
            self.conn.close()
            self.logger.write_log("Database connection closed.")

    def get_cursor(self):
        if not (self.conn and self.conn.open):
            self.connect()
        return self.conn.cursor()

    def commit(self):
        if self.conn and self.conn.open:
            self.conn.commit()

    def createTables(self):
        cursor = self.get_cursor()
        try:
            # students table
            sql = '''
            CREATE TABLE IF NOT EXISTS students (
            student_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(100) NOT NULL)
            '''
            cursor.execute(sql)
            self.commit()
            self.logger.write_log(f"students table created")


            # admins table
            sql = '''
            CREATE TABLE IF NOT EXISTS admins (
            admin_id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(100) NOT NULL)
            '''
            cursor.execute(sql)
            self.commit()
            self.logger.write_log(f"admins table created")


            # courses table
            sql = '''
            CREATE TABLE IF NOT EXISTS courses (
            course_id INT AUTO_INCREMENT PRIMARY KEY,
            course_name VARCHAR(100) NOT NULL,
            faculty_name VARCHAR(100) NOT NULL,
            UNIQUE(course_name, faculty_name))
            '''
            cursor.execute(sql)
            self.commit()
            self.logger.write_log(f"courses table created")


            # feedback table
            sql = '''
            CREATE TABLE IF NOT EXISTS feedback (
            feedback_id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            course_id INT NOT NULL,
            rating INT NOT NULL,
            comments TEXT,
            UNIQUE KEY unique_feedback (student_id, course_id),
            FOREIGN KEY (student_id) REFERENCES students(student_id),
            FOREIGN KEY (course_id) REFERENCES courses(course_id))
            '''
            cursor.execute(sql)
            self.commit()
            self.logger.write_log(f"feedback table created")       


        except pymysql.MySQLError as err:
            self.logger.write_log(f"Database connection / Table Creation failed: {err}")

        except Exception as e:
            self.logger.write_log(f"Database connection / Table Creation failed: {e}")      


    def addRecords(self):
        cursor = self.get_cursor()
        try:
            # admins table
            sql = '''
            INSERT IGNORE INTO admins (username, password) VALUES ('admin', 'root@123')
            '''            
            cursor.execute(sql)
            self.commit()
            self.logger.write_log(f"Record added in admins table")


            # courses table
            sql = '''
            INSERT IGNORE INTO courses (course_name, faculty_name) VALUES (%s, %s)
            '''            
            values = (
                ('Advanced Level C & C++', 'Prof. Dr. Kanetkar'),
                ('Python Boot Camp', 'Dr. Naren'),
                ('Advanced Level Linux', 'Mr. Torvalds'))
            
            cursor.executemany(sql, values)
            self.commit()
            self.logger.write_log(f"Records added in courses table")



        except pymysql.MySQLError as err:
            self.logger.write_log(f"Database connection / Records Insertion failed: {err}")

        except Exception as e:
            self.logger.write_log(f"Database connection / Records Insertion failed: {e}")      
