class DatabaseConnectionError(Exception):
    """Database connection failure."""
    pass

class DuplicateFeedbackError(Exception):
    """Duplicate feedback submission."""
    pass

class AuthenticationError(Exception):
    """Invalid login credentials."""
    pass

class FileHandlingError(Exception):
    """File read/write errors."""
    pass
