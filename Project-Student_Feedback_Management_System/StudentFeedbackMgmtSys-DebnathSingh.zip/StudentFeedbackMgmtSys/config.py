# config.py

MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'kol@mind1'
MYSQL_DATABASE = 'feedback_system'
LOG_FILE = 'app.log'
MYSQL_CONNECTION_TIMEOUT = 5
