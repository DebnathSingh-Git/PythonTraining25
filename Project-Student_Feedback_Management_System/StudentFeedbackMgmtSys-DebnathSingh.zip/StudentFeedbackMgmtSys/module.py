from database import DatabaseConnection
from custom_exceptions import DuplicateFeedbackError, AuthenticationError
from logger import Logger

# ---------------------------------------------------------------------------
# 1. User (Student) Module
# o	Students can register and log in.
# o	Students can submit feedback for courses/faculty.
# o	Each student can only submit feedback once per course.
class Student:
    def __init__(self, db: DatabaseConnection):
        self.db = db
        self.logger = Logger()

    def register(self, name, email, password):
        cursor = self.db.get_cursor()
        try:
            sql = "INSERT INTO students (name, email, password) VALUES (%s, %s, %s)"
            cursor.execute(sql, (name, email, password))
            self.db.commit()
            self.logger.write_log(f"New student registered: {email}")
        except Exception as e:
            # Check for duplicate email error
            self.logger.write_log(f"Student registration failed for {email}: {e}")
            if "Duplicate entry" in str(e):
                raise DuplicateFeedbackError(f"Student with email {email} already exists.")
            else:
                raise

    def login(self, email, password):
        cursor = self.db.get_cursor()
        sql = "SELECT * FROM students WHERE email = %s AND password = %s"
        cursor.execute(sql, (email, password))
        res = cursor.fetchone()
        if res:
            self.logger.write_log(f"Student login success: {email}")
            return res  # will have student_id etc.
        else:
            self.logger.write_log(f"Student login failed: {email}")
            raise AuthenticationError("Invalid student credentials.")

    def submit_feedback(self, student_id, course_id, rating, comments):
        cursor = self.db.get_cursor()
        # Check duplicate
        sql_check = "SELECT * FROM feedback WHERE student_id = %s AND course_id = %s"
        cursor.execute(sql_check, (student_id, course_id))
        if cursor.fetchone():
            self.logger.write_log(f"Feedback already submitted by Student_id {student_id} for course_id {course_id}")
            raise DuplicateFeedbackError("Feedback already submitted for this course by this student.")

        # Insert
        sql_insert = "INSERT INTO feedback (student_id, course_id, rating, comments) VALUES (%s, %s, %s, %s)"
        cursor.execute(sql_insert, (student_id, course_id, rating, comments))
        self.db.commit()
        self.logger.write_log(f"Feedback submitted by student_id {student_id} for course_id {course_id}")


# ---------------------------------------------------------------------------
# 2. User (Admin) Module
# o	Admin can log in.
# o	Admin can view all submitted feedback.
# o	Admin can download feedback logs stored in a file.
class Admin:
    def __init__(self, db: DatabaseConnection):
        self.db = db
        self.logger = Logger()

    def login(self, username, password):
        cursor = self.db.get_cursor()
        sql = "SELECT * FROM admins WHERE username = %s AND password = %s"
        cursor.execute(sql, (username, password))
        res = cursor.fetchone()
        if res:
            self.logger.write_log(f"Admin login success: {username}")
            return res
        else:
            self.logger.write_log(f"Admin login failed: {username}")
            raise AuthenticationError("Invalid admin credentials.")

    def view_feedback(self):
        cursor = self.db.get_cursor()
        sql = """
            SELECT f.feedback_id, s.name as student_name, c.course_name, c.faculty_name, f.rating, f.comments
            FROM feedback f
            JOIN students s ON f.student_id = s.student_id
            JOIN courses c ON f.course_id = c.course_id
        """
        cursor.execute(sql)
        results = cursor.fetchall()
        self.logger.write_log("Admin viewed all feedback")
        return results
