from datetime import datetime
from custom_exceptions import FileHandlingError
import config

class Logger:
    def __init__(self, logfile=None):
        self.logfile = logfile or config.LOG_FILE

    def write_log(self, message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_line = f"[{timestamp}] {message}\n"
        try:                
            with open(self.logfile, 'a') as f:
                f.write(log_line)

        except Exception as e:
            raise FileHandlingError(f"Failed to write log: {e}")
        
    def get_log(self):
        try:
            with open(self.logfile, 'r') as f:
                logcontent = f.readlines()
                return logcontent
        except Exception as e:
            raise FileHandlingError(f"Failed to read log: {e}")

