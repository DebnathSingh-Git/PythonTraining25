from flask import Flask, render_template, request, redirect, url_for, send_file
from database import DatabaseConnection
from module import Student, Admin
from logger import Logger
from custom_exceptions import AuthenticationError, DuplicateFeedbackError, DatabaseConnectionError, FileHandlingError
import config
import os
import atexit

app = Flask(__name__)

# Initialize
db = DatabaseConnection()
logger = Logger()

# # Before first request, try connect
# @app.before_first_request
# def init_db():
#     try:
#         db.connect()
#     except DatabaseConnectionError as e:
#         return f"Error connecting to database: {e}", 500

# ===========================================================
# @app.route('/')
# def home():
#     return redirect(url_for('student_login'))

@app.route('/')
def home():
    return render_template('home.html')


# -------- STUDENT MODULE --------

@app.route('/register', methods=['GET', 'POST'])
def student_register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        student = Student(db)
        try:
            student.register(name, email, password)
            logger.write_log("Registration successful.")
            return redirect(url_for('student_login'))
        except DuplicateFeedbackError as e:
            logger.write_log(str(e))
        except Exception as e:
            logger.write_log(f"Exception during registration: {e}")
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        student = Student(db)
        try:
            user = student.login(email, password)
            return redirect(url_for('submit_feedback', student_id = user['student_id']))
        except AuthenticationError as e:
            logger.write_log(str(e))
        except Exception as e:
            logger.write_log(f"Exception during student login: {e}")
    return render_template('login_student.html')

@app.route('/submit_feedback', methods=['GET', 'POST'])
def submit_feedback():
    student_id = request.args.get('student_id')
    logger.write_log(f"Submitting feedback for student_id: {student_id}")
    
    # fetch courses
    cursor = db.get_cursor()
    try:
        cursor.execute("SELECT * FROM courses")
        courses = cursor.fetchall()
    except Exception as e:
        logger.write_log(f"Error fetching courses: {e}")
        courses = []

    if request.method == 'POST':
        course_id = request.form.get('course_id')
        rating = request.form.get('rating')
        comments = request.form.get('comments')
        student = Student(db)
        try:
            logger.write_log("Submitting feedback...")
            student.submit_feedback(student_id, course_id, rating, comments)
            logger.write_log("Feedback submitted successfully.")
            return redirect(url_for('submit_feedback', student_id = student_id))
        except DuplicateFeedbackError as e:
            logger.write_log(str(e))
        except Exception as e:
            logger.write_log(f"Exception during feedback submission: {e}")

    return render_template('submit_feedback.html', courses=courses)

@app.route('/logout_student')
def logout_student():
    logger.write_log("Logged out.")
    return redirect(url_for('student_login'))

# -------- ADMIN MODULE --------

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        admin = Admin(db)
        try:
            user = admin.login(username, password)
            return redirect(url_for('view_feedback'))
        except AuthenticationError as e:
            logger.write_log(str(e))
        except Exception as e:
            logger.write_log(f"Exception during admin login: {e}")
    return render_template('login_admin.html')

@app.route('/admin/view_feedback')
def view_feedback():
    admin = Admin(db)
    try:
        all_feedback = admin.view_feedback()
    except Exception as e:
        logger.write_log(f"Exception retrieving feedback: {e}")
        all_feedback = []
    return render_template('view_feedback.html', feedbacks=all_feedback)

@app.route('/admin/download_logs')
def download_logs():
    try:
        # Serve the log file for download
        return send_file(config.LOG_FILE, as_attachment=True)
    except Exception as e:
        logger.write_log(f"Error downloading log file: {e}")
        return redirect(url_for('view_feedback'))
    
@app.route('/admin/view_logs')
def view_logs():
    try:
        #  get log file content
        contents = logger.get_log()
        # return content
    except Exception as e:
        logger.write_log(f"Error viewing log file: {e}")
        return redirect(url_for('view_feedback'))
    return render_template('view_log.html', logs=contents)    

@app.route('/admin/logout')
def logout_admin():
    logger.write_log("Admin logged out.")
    return redirect(url_for('admin_login'))

# ----------------------------------------------------------------------------------------------------
# -------- Shutdown/cleanup --------
# If we want at the end of each application context, meaning:
# It will run after each HTTP request — not just when the app shuts down.
# @app.teardown_appcontext
# def shutdown_db(exception):
#     try:
#         db.disconnect()
#     except Exception as e:
#         logger.write_log(f"Exception during DB disconnect: {e}")


# If we want at the time of Appliaction shutting down
@atexit.register
def cleanup_on_exit():
    try:
        db.disconnect()
        logger.write_log("Application is shutting down. DB disconnected.")
    except Exception as e:
        logger.write_log(f"Application is shutting down. Exception during DB disconnect: {e}")
# ----------------------------------------------------------------------------------------------------

if __name__ == '__main__':
    # Ensure the log file exists
    if not os.path.exists(config.LOG_FILE):
        open(config.LOG_FILE, 'w').close()
    logger.write_log("============ Student Feedback Management System 1.0 ============")

    try:
        # Create the database
        db.createDB()

        # Connect to the database
        db.connect()

        # Create Tables
        db.createTables()
        
        # Add Records in 'admins' and 'courses' Tables
        db.addRecords()
        
    except DatabaseConnectionError as e:
        logger.write_log(str(e))
        exit(1)

    except Exception as e:
        logger.write_log(str(e))
        exit(1)        
                
    app.run(debug=True, use_reloader=False)
